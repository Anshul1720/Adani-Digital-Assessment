#include <iostream>
#include <cstdlib> 
#include <ctime> 
using namespace std;

int** create2DList(int numberOfRows, int numberOfColumns) {
    srand(time(0));
    int** list = new int*[numberOfRows];
    for(int i = 0; i < numberOfRows; i++) {
        list[i] = new int[numberOfColumns];
        for(int j = 0; j < numberOfColumns; j++) {
            list[i][j] = rand() % 101; 
        }
    }
    return list;
}

int main() {
    int numberOfRows;
    int numberOfColumns;
    cout<<"Enter number of rows: ";
    cin >> numberOfRows;
    cout<<"Enter number of columns: ";
    cin >> numberOfColumns;
    int** myList = create2DList(numberOfRows, numberOfColumns);
    for(int i = 0; i < numberOfRows; i++) {
        for(int j = 0; j < numberOfColumns; j++) {
            cout << myList[i][j] << " ";
        }
        cout << endl;
    }
    return 0;
}
