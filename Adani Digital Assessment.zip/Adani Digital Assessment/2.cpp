#include <iostream>
#include <algorithm>
using namespace std;

int** create2DList(int numberOfRows, int numberOfColumns) {
    srand(time(0));
    int** list = new int*[numberOfRows];
    for(int i = 0; i < numberOfRows; i++) {
        list[i] = new int[numberOfColumns];
        for(int j = 0; j < numberOfColumns; j++) {
            list[i][j] = rand() % 101; 
        }
    }
    return list;
}

int** sort2DList(int** list, int numberOfRows, int numberOfColumns, int columnIndex) {
    int* columnValues = new int[numberOfRows];
    for(int i = 0; i < numberOfRows; i++) {
        columnValues[i] = list[i][columnIndex];
    }
    sort(columnValues, columnValues + numberOfRows);
    int** sortedList = new int*[numberOfRows];
    for(int i = 0; i < numberOfRows; i++) {
        sortedList[i] = new int[numberOfColumns];
    }
    for(int i = 0; i < numberOfRows; i++) {
        int currentValue = columnValues[i];
        for(int j = 0; j < numberOfRows; j++) {
            if(list[j][columnIndex] == currentValue) {
                for(int k = 0; k < numberOfColumns; k++) {
                    sortedList[i][k] = list[j][k];
                }
                break;
            }
        }
    }
    return sortedList;
}

int main() {
    int numberOfRows;
    int numberOfColumns;
    cout<<"Enter number of rows: ";
    cin >> numberOfRows;
    cout<<"Enter number of columns: ";
    cin >> numberOfColumns;
    int** myList = create2DList(numberOfRows, numberOfColumns);
    cout << "Original list:" << endl;
    for(int i = 0; i < numberOfRows; i++) {
        for(int j = 0; j < numberOfColumns; j++) {
            cout << myList[i][j] << " ";
        }
        cout << endl;
    }
    int columnIndex;
    cout << "Enter column index: ";
    cin >> columnIndex;
    int** sortedList = sort2DList(myList, numberOfRows, numberOfColumns, columnIndex);
    cout << "Sorted list based on column " << columnIndex << ":" << endl;
    for(int i = 0; i < numberOfRows; i++) {
        for(int j = 0; j < numberOfColumns; j++) {
            cout << sortedList[i][j] << " ";
        }
        cout << endl;
    }
    return 0;
}
